package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.repositories.EmployeeRepo;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepo employeeRepo;
	
	public Employee getEmployee(int employeeId)
	{
		return employeeRepo.findById(employeeId).orElse(null);
	}
	
	public Employee savEmployee(Employee employee) {
		
		return employeeRepo.save(employee);
		
		
	}
	
}
