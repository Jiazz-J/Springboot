package com.virtusa.vrps.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.RatingAndComments;
import com.virtusa.vrps.repositories.ApplicationRepo;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class AdminController {
	
	@Autowired
	HttpSession httpSession;
	
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private CompanyService companyService;
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private ApplicationService applicationService;
	
	@ModelAttribute("personalDetails")
	public List<Personal> getAllPersonalDetails(){
		return personalService.getAllPersonal();
	}
	
	
	@PostMapping("/employeeStatus")
	public String selected(@RequestParam("employeeId") int employeeId,@RequestParam("result") String result,RatingAndComments rAC) {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		//employeeId = Integer.parseInt(employeeId));
	    System.out.print(employeeId);
	    String role=httpSession.getAttribute("role").toString();
		applicationService.updateStatus(employeeId, role, 1);
		return "viewselectedcandidate";
	}
	
	@GetMapping("/rejected")
	public String rejected(@RequestParam("id") String id) {
		int employeeId = Integer.parseInt(id);
		String role=httpSession.getAttribute("role").toString();
		applicationService.updateStatus(employeeId, role, 2);
		return "viewcandidate";
	}
	
	@GetMapping("/viewcandidate")
	public String employeeList(Model model) {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		String Role=httpSession.getAttribute("role").toString();
		model.addAttribute("workDetails",workService.customeFindAllWorkDetails(Role));
		/*
		 * model.addAttribute("personalDetails",personalService.
		 * customeFindAllPersonalDetails(Role));
		 */
		return "viewcandidate";
	}
	
	@GetMapping("/viewselectedcandidate")
	public String selectedemployeeList(Model model) {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		String Role=httpSession.getAttribute("role").toString();
		model.addAttribute("workDetails", workService.customeFindSelectedWorkDetails(Role));
		return "viewcandidate";
	}
	
	
	
	@GetMapping( "/viewemployeedetail")
	public String abcd(@RequestParam("id") String id,Model model) {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		System.out.println("id:"+id);
		
		int employeeId = Integer.parseInt(id);
		
		model.addAttribute("personal", personalService.getPersoalById(employeeId));
		model.addAttribute("educations", educationService.getEducationById(employeeId));
		model.addAttribute("work", workService.getWorkById(employeeId));
		model.addAttribute("companies", companyService.getApplicationById(workService.getWorkById(employeeId).getWorkId()));
		
		return "candidateProfile";
	}
	
	
	

	@GetMapping("/adminHome")
	public String adminHome() {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		int employeeId=Integer.parseInt(authentication.getName());
		httpSession.setAttribute("userId", employeeId);
		httpSession.setAttribute("role", authentication.getAuthorities());
		
		
		
		System.out.println(Integer.parseInt(httpSession.getAttribute("userId").toString())+"  name  "+authentication.getAuthorities() );
		return "adminHome";
	}
	
	
	@GetMapping("/candidateProfile")
	public String candidateProfile() {
		 if(httpSession.getAttribute("userId")==null)
		    	return "login";
		return "candidateProfile";
	}
	
	
	
	

}
