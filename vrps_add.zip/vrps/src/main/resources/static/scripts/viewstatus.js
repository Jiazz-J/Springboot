$(document).ready(function () {
	console.log("ok")
    $("#getstatus").click(function () {
    	  console.log("ok")
        //stop submit the form, we will post it manually.
        event.preventDefault();

        fire_ajax_submit();

    });

});

function fire_ajax_submit() {

    var referenceId = $("#referenceId").val();
    console.log(referenceId);
     $("#getstatus").prop("disabled", true);

    var application={
    		"referenceId":referenceId
    }
    console.log("ok")
    $.ajax({
        type: "Post",
        contentType: "application/json",
        url: "/getstatusbyrefid",
        data: JSON.stringify(application),
     
 success: function (data) {

	  console.log("sucess");
	      
        	$('#status').html(data);
        	$("#getstatus").prop("disabled", false);
        },
        error: function (e) {
            console.log("error");
   	     
        	$('#status').html("invalid refrenceId");
        	$("#getstatus").prop("disabled", false);
        }
    });

}