package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Admin;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.repositories.AdminRepo;
import com.virtusa.vrps.repositories.ApplicationRepo;

@Service
public class AdminService {

	@Autowired
	private AdminRepo adminRepo;
	
	
public Admin saveAdmin(Admin admin) {
		
		return adminRepo.save(admin);
			
	}
	
	
	
	
	
	
	
}
