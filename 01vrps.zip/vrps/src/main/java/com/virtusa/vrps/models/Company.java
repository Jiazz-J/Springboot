package com.virtusa.vrps.models;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Company")
public class Company {

	@Id
	@Column(name = "CompanyId")
	private int companyId;
	@OneToMany()
	@Column(name = "WorkId")
	private int workId;
	@Column(name = "CompanyName")
	private String companyName;
	@Column(name = "StartDate")
	private LocalDate startDate;
	@Column(name = "EndDate")
	private LocalDate endDate;
	@Column(name = "TechnologiesWorked")
	private String technologiesWorked;
	@Column(name = "PreviousPackage")
	private int previousPackage;

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public int getWorkId() {
		return workId;
	}

	public void setWorkId(int workId) {
		this.workId = workId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getTechnologiesWorked() {
		return technologiesWorked;
	}

	public void setTechnologiesWorked(String technologiesWorked) {
		this.technologiesWorked = technologiesWorked;
	}

	public int getPreviousPackage() {
		return previousPackage;
	}

	public void setPreviousPackage(int previousPackage) {
		this.previousPackage = previousPackage;
	}

}
