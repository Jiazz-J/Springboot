package com.virtusa.vrps.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "RatingAndComments")
public class RatingAndComments {

	@Id
	private int rACId;

	@OneToMany
	private int employeeId;

	@OneToMany
	private int adminId;

	@OneToMany
	private int jobId;

	private int rating;
	private String comments;

	public int getrACId() {
		return rACId;
	}

	public void setrACId(int rACId) {
		this.rACId = rACId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
