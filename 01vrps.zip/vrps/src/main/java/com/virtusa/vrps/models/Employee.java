package com.virtusa.vrps.models;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee extends Person {

}
