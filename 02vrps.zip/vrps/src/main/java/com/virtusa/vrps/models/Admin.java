package com.virtusa.vrps.models;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Admin")
@PrimaryKeyJoinColumn
public class Admin extends Person {
	
	
	
	  @OneToMany 
	  private List<RatingAndComments> ratingAndComments;
	  
	  @OneToMany
	  private List<Application> Application;
	  
	  @OneToMany
	  private List<Job> job;
	 
}
