package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.repositories.PersonalRepo;

@Service
public class PersonalService {

	@Autowired
	private PersonalRepo personalRepo;
}
