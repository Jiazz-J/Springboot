package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.RatingAndComments;

public interface RatingAndCommentsRepo extends JpaRepository<RatingAndComments, Integer>{

}
