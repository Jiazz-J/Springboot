package com.virtusa.vrps.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.repositories.WorkRepo;

@Service
public class WorkService {

	@Autowired
	private WorkRepo workRepo;
}
