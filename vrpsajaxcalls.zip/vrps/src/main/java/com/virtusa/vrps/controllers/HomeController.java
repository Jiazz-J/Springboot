package com.virtusa.vrps.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
	
	
   @GetMapping("/jobList")
   public String joblist() {
	   
	   return "jobList";
   }
	@GetMapping("/createProfile")
	public String createProfile()
	{
		return "createProfile";
		
	}
   
	

}
