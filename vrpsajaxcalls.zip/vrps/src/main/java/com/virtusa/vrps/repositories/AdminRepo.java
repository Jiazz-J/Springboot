package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.Admin;

public interface AdminRepo extends JpaRepository<Admin, Integer>{
	
	

}
