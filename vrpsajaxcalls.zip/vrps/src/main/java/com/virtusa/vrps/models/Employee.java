package com.virtusa.vrps.models;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
@PrimaryKeyJoinColumn
public class Employee extends Person {

	/*
	 * @OneToOne(mappedBy = "Employee", cascade = CascadeType.ALL) private Personal
	 * personal;
	 */
	/*
	 * @OneToOne private Application application;
	 * 
	 * @OneToOne private Personal personal;
	 * 
	 * @OneToOne private Work work;
	 * 
	 * @OneToMany private List<Education> education;
	 * 
	 * @OneToOne private Job job;
	 */

	/*
	 * public Personal getPersonal() { return personal; }
	 * 
	 * public void setPersonal(Personal personal) { this.personal = personal; }
	 */
	/*
	 * @OneToMany
	 * 
	 * @JoinColumn(name = "Rating") private List<RatingAndComments>
	 * ratingAndComments;
	 * 
	 * public List<RatingAndComments> getRatingAndComments() { return
	 * ratingAndComments; } public void setRatingAndComments(List<RatingAndComments>
	 * ratingAndComments) { this.ratingAndComments = ratingAndComments; }
	 * 
	 * public Personal getPersonal() { return personal; } public void
	 * setPersonal(Personal personal) { this.personal = personal; } public Work
	 * getWork() { return work; } public void setWork(Work work) { this.work = work;
	 * }
	 * 
	 * public Application getApplication() { return application; } public void
	 * setApplication(Application application) { this.application = application; }
	 * public List<Education> getEducation() { return education; } public void
	 * setEducation(List<Education> education) { this.education = education; }
	 * public Job getJob() { return job; } public void setJob(Job job) { this.job =
	 * job; }
	 * 
	 */
}
