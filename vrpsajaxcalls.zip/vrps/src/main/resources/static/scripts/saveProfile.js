/*$(document).ready(function(){
	 
	
	
	$("#regForm").submit(function (event) {
		  cosole.log("dubmit");
	
	
	
	


	});
	
});
	*/	



var groupeducation=[];
$(document).ready(function () {
	 
    $("#regForm").submit(function (event) {
 
        //stop submit the form, we will post it manually.
        event.preventDefault();
       
        alert("Hello! I am an alert box!!");
      
        fire_ajax_submit();
       
 
    });
    
    
    $("#addeducation").click(function (event) {
   	 
        //stop submit the form, we will post it manually.
      
       
        alert("Hello! I am an alert box!!");
      //education
        var course = $("#course").val();
        var branch = $("#branch").val();
        var institutionName = $("#institutionName").val();
        var percentage = $("#percentage").val();
        var passYear = $("#passYear").val();
        
        
//        console.log(course+"name");
//        console.log(branch+"gender");
//        console.log(institutionName+"mobile");
//        console.log(passYear+"emai");
        $('#educlose').trigger('click');
        
    
       var education={
        		
        		"course":course,
        		"branch":branch,
        		"institutionName":institutionName,
        		"percentage":percentage,
        		"passYear":passYear
        }
       
        groupobj(education);
       

    });
    
    function groupobj(education){
   
 
   
   
 	   groupeducation.push(education);
    
    
    console.log(groupeducation);
    for(var i=0;i<groupeducation.length;i++)
    console.log(groupeducation[i]);
    
    }
    
 
});


//button start ajax call
function fire_ajax_submit() {
   
        //personal
    var fullName = $("#name").val();
    var dob= $("#dob").val();
    var gender =  $("input[name='gender']:checked").val();
    var mobile = $("#mobile").val();
    var email = $("#email").val();
    var address = $("#address").val();
    
    console.log(fullName+"name");
    console.log(gender+"gender");
    console.log(mobile+"mobile");
    console.log(email+"em;ai");
    //work
    var experience=$("#experience").val();
    var location=$("#location").val();
    var projectStatus=$("#projectStatus").val();
    var skills=$("#skills").val();
   
    
    
    
    
    $("#nextBtn").prop("disabled", true);
 
    var personal={
              
                "address":address,
                
                "dob":  dob,
                
                "email":email,
                "gender":gender,
                "mobile":mobile,
               
                "name":fullName,
                
    }
   
    var work={
                "experience" : experience,
                "location" : location,
                "projectStatus" : projectStatus,
                "skills" : skills
    }
    
   
 var Education={
               
    		
    }
 var Company={
               
    }
    var cmdobjec={
       
                objpersonal:personal,
                objwork:work
                //objedu:Education,
                //objcmpy:Company      
    }
   
   
    $.ajax({
       
        type: "POST",
        contentType: "application/json",
        url: "/saveEducation",
        data: groupeducation,
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
 
                console.log("Hello world! ajax");
                $("#feedback tr").remove();
                var $tr = $('<tr>');
                 $.each(data, function(i, item) {
                       
                         $tr.append(
                            $('<td>').text(item)
                        ); //.appendTo('#records_table');
                       
                    });
                 $('#feedback').append($tr);
                 
            $("#nextBtn").prop("disabled", false);
 
        },
        error: function (e) {
 
            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#feedback').html(json);
 
            console.log("ERROR : ", e);
            $("#nextBtn").prop("disabled", false);
 
        }
   
});
}// ajax call ends



