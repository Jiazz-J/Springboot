package com.virtusa.partialrequestajax.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.partialrequestajax.models.Customer;
import com.virtusa.partialrequestajax.repositories.CustomerRepo;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepo customerRepo;
	
	public Customer getCustomerById(int customerId) {
		return customerRepo.findById(customerId).orElse(null);
		
	}

}
