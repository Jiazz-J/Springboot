package com.virtusa.partialrequestajax.configurations;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import com.virtusa.partialrequestajax.filters.CustomerFilter;

@Configuration
public class FilterConfiguration {

	@Bean
	public FilterRegistrationBean<CustomerFilter> getFilter(){
		
		
		FilterRegistrationBean<CustomerFilter> reg=new 
				FilterRegistrationBean<CustomerFilter>();
		CustomerFilter filter =new CustomerFilter();
		reg.setFilter(filter);
		reg.addUrlPatterns("/*");
		reg.setOrder(1);
		return reg;
	}
	
	
}
