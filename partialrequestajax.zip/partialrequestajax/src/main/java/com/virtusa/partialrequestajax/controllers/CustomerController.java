package com.virtusa.partialrequestajax.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.virtusa.partialrequestajax.models.Customer;
import com.virtusa.partialrequestajax.services.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/home")
	public String loadHome() {
		return "index";
	}
	
	@PostMapping("/getcustomerbyid")
	public @ResponseBody Customer
	findByCustomerId(@RequestBody Customer customer) {
		
		//System.out.println( customerService.getCustomerById(customer.getCustomerId())+"    debugg");
		
		return customerService.getCustomerById(customer.getCustomerId());
	}
}
