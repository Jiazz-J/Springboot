package com.virtusa.vrps.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.virtusa.vrps.models.Admin;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.PersonRole;
import com.virtusa.vrps.repositories.EmployeeRepo;
import com.virtusa.vrps.repositories.PersonRoleRepo;
import com.virtusa.vrps.services.AdminService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.PersonRoleService;

@Controller
public class HomeController {
	
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private PersonRoleService personRoleService;
	
	@Autowired
	AdminService adminService;
	
	@Autowired
	HttpSession httpSession;
	
   @GetMapping("/")
   public String login()
   {
	   return "login";
   }
   
   @GetMapping("/logout")
   public String logout()
   {
	   httpSession.removeAttribute("userId");
	   httpSession.removeAttribute("role");
	
	   httpSession.invalidate();
	   return "login";
	  
   }
   
  
	
	/*
	 * @GetMapping("/emp") public String dataPopulateUser(Employee employee, Admin
	 * admin,PersonRole personRole) {
	 * 
	 * int i=1234; employee.setEmployeeId(i); employee.setPassword(new
	 * BCryptPasswordEncoder().encode(i+""));
	 * employee=employeeService.savEmployee(employee); personRole.setId(i);
	 * personRole.setRole("ROLE_USER");
	 * personRoleService.savePersonRole(personRole);
	 * 
	 * int j=9234; admin.setEmployeeId(j); admin.setPassword(new
	 * BCryptPasswordEncoder().encode(j+"")); admin=adminService.saveAdmin(admin);
	 * personRole.setId(j); personRole.setRole("ROLE_ADMIN");
	 * personRoleService.savePersonRole(personRole);
	 * 
	 * int k=8234; admin.setEmployeeId(k); admin.setPassword(new
	 * BCryptPasswordEncoder().encode(k+"")); admin=adminService.saveAdmin(admin);
	 * personRole.setId(k); personRole.setRole("ROLE_HR");
	 * personRoleService.savePersonRole(personRole);
	 * 
	 * 
	 * int l=7234; admin.setEmployeeId(l); admin.setPassword(new
	 * BCryptPasswordEncoder().encode(l+"")); admin=adminService.saveAdmin(admin);
	 * personRole.setId(l); personRole.setRole("ROLE_TR");
	 * personRoleService.savePersonRole(personRole);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * System.out.println( "Successs"); return "login";
	 * 
	 * 
	 * }
	 * 
	 */}
