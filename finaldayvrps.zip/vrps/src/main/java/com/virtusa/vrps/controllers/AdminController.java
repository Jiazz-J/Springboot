package com.virtusa.vrps.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.repositories.ApplicationRepo;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class AdminController {
	
	
	@Autowired
	private ApplicationService applicationService;
	
	@Autowired
	private PersonalService personalService;
	
	@Autowired
	private EducationService educationService;
	
	@Autowired
	private CompanyService compnayService;
	
	@Autowired
	private WorkService workService;
	
	

	@GetMapping("/adminHome")
	public String adminHome() {

		return "adminHome";
	}
	
	
	
	
	/*
	 * @GetMapping("/allcandidates") public ModelAndView allCandidates()
	 */
	@GetMapping("/getallcandidates")
	public String getCandidatesList()
	{
		ModelAndView mav=null;
		List<Integer> employeeId=applicationService.getAllAppliedEmployeeList();
		List<Personal> personal = new ArrayList<Personal>();
		for(int i=0;i<employeeId.size();i++)
		{
			System.out.print(employeeId.get(i));
			//personal.add(personalService.getPersonalByEmployeeId(employeeId.get(i)));
		}
		//System.out.print("personal"+personal.size());
		
		return "candidateList";
	}

}
