package com.virtusa.vrps.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;


import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.services.ApplicationService;

@Controller
public class ViewStatusController {

	@Autowired
	private ApplicationService applicationService;
	
	@GetMapping("/viewstatus")
	public String viewStatus() {
		
		return "viewStatus";
	}
	
	@PostMapping("/getstatusbyrefid")
	public @ResponseBody String getCustomerById(@RequestBody Application application)
	{
		System.out.println("working");
		System.out.println(application.getReferenceId());
		Application applicationResult=applicationService.getApplicationByRefId(application.getReferenceId());
		System.out.println(applicationResult);
		
		String status="invalid referenceId";
    
		if(applicationResult.getAdminStatus()==2 || applicationResult.getAdminStatus()==2 || applicationResult.getAdminStatus()==2 )
		{
			status="your rejected";
		}
		else 
		{
			if(applicationResult.getAdminStatus()==1)
			{
				status="your selected by admin ";
				if(applicationResult.getTrStatus()==1)
				{
					status="your selected by tr ";
					if(applicationResult.getHrStatus()==1)
					{
						status="your selected by hr ";
					}
				}
			}
			else
			{
				status="your are just applied ";
			}
		}
			
		return status;
	}
}
