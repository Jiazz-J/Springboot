package com.virtusa.vrps.models;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@Entity
@Table(name = "Company")
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CompanyId")
	private int companyId;
	
	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn
	private Work work;
	
	@Column(name = "CompanyName")
	private String companyName;
	@Column
	private String designation;
	
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@DateTimeFormat(iso = ISO.DATE)
	@Column(name = "StartDate")
	private LocalDate startDate;
	@DateTimeFormat(iso = ISO.DATE)
	@Column(name = "EndDate")
	private LocalDate endDate;
	@Column(name = "TechnologiesWorked")
	private String technologiesWorked;
	@Column(name = "PreviousPackage")
	private int previousPackage;

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	
	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getTechnologiesWorked() {
		return technologiesWorked;
	}

	public void setTechnologiesWorked(String technologiesWorked) {
		this.technologiesWorked = technologiesWorked;
	}

	public int getPreviousPackage() {
		return previousPackage;
	}

	public void setPreviousPackage(int previousPackage) {
		this.previousPackage = previousPackage;
	}

	public Work getWork() {
		return work;
	}

	public void setWork(Work work) {
		this.work = work;
	}

}
