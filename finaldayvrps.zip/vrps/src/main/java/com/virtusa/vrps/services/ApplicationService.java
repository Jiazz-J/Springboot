package com.virtusa.vrps.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.repositories.ApplicationRepo;

@Service
public class ApplicationService {

	@Autowired
	private ApplicationRepo applicationRepo;
	
	public Application saveApplication(Application application) {
		return applicationRepo.save(application);

	}

	public List<Application> getAllApplications() {
		return applicationRepo.findAll();

	}
	public List<Integer> getAllAppliedEmployeeList()
	{
	   List<Application> application=applicationRepo.findAll();
	   System.out.println("in application service");
	   System.out.println(application.size());
	   List<Integer> employeeId =new ArrayList<Integer>();
	   for(int i=0;i<application.size();i++)
	   {
		   employeeId.add(application.get(i).getEmployee().getEmployeeId());
		   System.out.print(application.get(i).getEmployee().getEmployeeId());
	   }
	   
	   return employeeId;
	   
	}

	public Application getApplicationById(int applicationId) {
		return applicationRepo.findById(applicationId).orElse(null);
	}
	
}
