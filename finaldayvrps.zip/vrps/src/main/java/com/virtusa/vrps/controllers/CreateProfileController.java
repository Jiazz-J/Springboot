package com.virtusa.vrps.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.virtusa.vrps.models.Company;
import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class CreateProfileController {

	@Autowired
	private PersonalService personalService;

	@Autowired
	private WorkService workService;
	
	@Autowired
	EmployeeService employeeService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private EducationService educationService;
	
	
	
	@RequestMapping(value = "/savePersonal",method=RequestMethod.POST)
	public String savePersonal(@RequestBody Personal personal,Employee employee, Model model) {
//		System.out.println(personal.getEmployee().getEmployeeId());
//		System.out.println(personal.getEmployee());
		 employee=employeeService.getEmployee(9876);
		 personal.setEmployee(employee);
		model.addAttribute("personal", personalService.savePersonal(personal));
		return "employeeHome";

	}

	@RequestMapping(value = "/saveWork",method=RequestMethod.POST)
	  
	public void saveWork(@RequestBody Work work, Model model) {
	//	model.addAttribute("work", workService.saveWork(work));
		workService.saveWork(work);

	}

	 @RequestMapping(value = "/saveCompany",method=RequestMethod.POST)
	  
	public void saveCompany(@RequestBody Company[] groupcompany, Model model)
	{
		//model.addAttribute("company", companyService.saveCompany(company));	
		 for(int i=0;i<groupcompany.length;i++)
		  {
			 //System.out.println(groupcompany[i].getBranch());
			 companyService.saveCompany(groupcompany[i]);
		  }
	}

	
	  @RequestMapping(value = "/saveEducation",method=RequestMethod.POST)
	  
	  public void saveWork(@RequestBody Education[] groupeducation, Model model) {
		  
		  
	  //model.addAttribute("work", workService.saveWork(education));
	 System.out.println( groupeducation.length);
	  
	  for(int i=0;i<groupeducation.length;i++)
	  {
		 System.out.println(groupeducation[i].getBranch());
		 educationService.saveEducation(groupeducation[i]);
	  }
	 
	  
	  }
	 
	
	
	
	
	
}
