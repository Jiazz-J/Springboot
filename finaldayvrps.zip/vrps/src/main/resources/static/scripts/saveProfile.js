/*$(document).ready(function(){
	 
	
	
	$("#regForm").submit(function (event) {
		  cosole.log("dubmit");
	
	
	
	


	});
	
});
	*/	



var groupeducation=[];
var groupcompany=[];
$(document).ready(function () {
	 
    $("#regForm").submit(function (event) {
 
        //stop submit the form, we will post it manually.
        event.preventDefault();
       
        alert("Hello! I am an alert box!!");
      
        fire_ajax_submit();
       
 
    });
    
    
    $("#addeducation").click(function (event) {
   	 
        //stop submit the form, we will post it manually.
      
       
        alert("Hello! I am an alert box!!");
      //education
        var course = $("#course").val();
        var branch = $("#branch").val();
        var institutionName = $("#institutionName").val();
        var percentage = $("#percentage").val();
        var passYear = $("#passYear").val();
        
        
//        console.log(course+"name");
//        console.log(branch+"gender");
//        console.log(institutionName+"mobile");
//        console.log(passYear+"emai");
        $('#educlose').trigger('click');
        
    
       var education={
        		
        		"course":course,
        		"branch":branch,
        		"institutionName":institutionName,
        		"percentage":percentage,
        		"passYear":passYear
        }
       
       
      // document.querySelector("#educationdd").append(education);
       
      
       eduprint(education);
       groupeducation.push(education);
       
    });
    
    
    
    
    
    
    $("#addCompanydetails").click(function (event) {
      	 
        //stop submit the form, we will post it manually.
      
       
        alert("Hello! I am an alert box!!");
      //education
        var companyName = $("#companyName").val();
        var designation = $("#designation").val();
        var startDate = $("#startDate").val();
        var endDate = $("#endDate").val();
        var previousPackage = $("#previousPackage").val();
        var technologiesWorked = $("#technologiesWorked").val();
        
        
//        console.log(course+"name");
//        console.log(branch+"gender");
//        console.log(institutionName+"mobile");
//        console.log(passYear+"emai");
        $('#companyclose').trigger('click');
       
        
    
       var company={
        		
        		"companyName":companyName,
        		"designation":designation,
        		"startDate":startDate,
        		"endDate":endDate,
        		"previousPackage":previousPackage,
        		"technologiesWorked":technologiesWorked,
        		
        }
       
    
       comprint(company)
       groupcompany.push(company);
       
    });
    
  
    
 
});




function comprint(company) {
	   
    console.log("Hello world! ajax");
   // $("#feedback tr").remove();
    var $table=$('<table>');
    var $tr = $('<tr>');
  
     $.each(company, function(i, item) {
           
             $tr.append(
                $('<td>').text(item)
            ); //.appendTo('#records_table');
          
        });
     
     $table.append($tr);
     $('#companydd').append($table);
     
$("#nextBtn").prop("disabled", false);

}


function eduprint(education) {
	   
    console.log("Hello world! ajax");
   // $("#feedback tr").remove();
    
    var $table=$('<table>');
    var $tr = $('<tr>');
  
     $.each(education, function(i, item) {
           
             $tr.append(
                $('<td>').text(item)
            ); //.appendTo('#records_table');
             
           
           
        });
     
     $table.append($tr);
     $('#educationdd').append($table);
     
$("#nextBtn").prop("disabled", false);

}




//button start ajax call
function fire_ajax_submit() {
   
        //personal
    var fullName = $("#name").val();
    var dob= $("#dob").val();
    var gender =  $("input[name='gender']:checked").val();
    var mobile = $("#mobile").val();
    var email = $("#email").val();
    var address = $("#address").val();
    
    console.log(fullName+"name");
    console.log(gender+"gender");
    console.log(mobile+"mobile");
    console.log(email+"em;ai");
    //work
    var experience=$("#experience").val();
    var location=$("#location").val();
    var projectStatus=$("#projectStatus").val();
    var skills=$("#skills").val();
   
    
    
    
    
    $("#nextBtn").prop("disabled", true);
 
    var personal={
              
                "address":address,
                
                "dob":  dob,
                
                "email":email,
                "gender":gender,
                "mobile":mobile,
               
                "name":fullName,
                
    }
   
    var work={
                "experience" : experience,
                "location" : location,
                "projectStatus" : projectStatus,
                "skills" : skills
    }
    
    
    
    $.ajax({
        
        type: "POST",
        contentType: "application/json",
        url: "/savePersonal",
        data: JSON.stringify(personal),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
 
                console.log("Hello world! ajax");
                $("#feedback tr").remove();
                var $tr = $('<tr>');
                 $.each(data, function(i, item) {
                       
                         $tr.append(
                            $('<td>').text(item)
                        ); //.appendTo('#records_table');
                       
                    });
                 $('#feedback').append($tr);
                 
            $("#nextBtn").prop("disabled", false);
 
        },
        error: function (e) {
 
            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#feedback').html(json);
 
            console.log("ERROR : ", e);
            $("#nextBtn").prop("disabled", false);
 
        }
   
});
    
    
    $.ajax({
        
        type: "POST",
        contentType: "application/json",
        url: "/saveWork",
        data: JSON.stringify(work),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
 
                console.log("Hello world! ajax");
                $("#feedback tr").remove();
                var $tr = $('<tr>');
                 $.each(data, function(i, item) {
                       
                         $tr.append(
                            $('<td>').text(item)
                        ); //.appendTo('#records_table');
                       
                    });
                 $('#feedback').append($tr);
                 
            $("#nextBtn").prop("disabled", false);
 
        },
        error: function (e) {
 
            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#feedback').html(json);
 
            console.log("ERROR : ", e);
            $("#nextBtn").prop("disabled", false);
 
        }
   
});
   
   
    $.ajax({
       
        type: "POST",
        contentType: "application/json",
        url: "/saveEducation",
        data: JSON.stringify(groupeducation),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
 
                console.log("Hello world! ajax");
               // $("#feedback tr").remove();
                var $tr = $('<tr>');
                 $.each(data, function(i, item) {
                       
                         $tr.append(
                            $('<td>').text(item)
                        ); //.appendTo('#records_table');
                       
                    });
                 $('#educationdd').append($tr);
                 
            $("#nextBtn").prop("disabled", false);
 
        },
        error: function (e) {
 
            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#company').html(json);
 
            console.log("ERROR : ", e);
            $("#nextBtn").prop("disabled", false);
 
        }
   
});
    
    $.ajax({
        
        type: "POST",
        contentType: "application/json",
        url: "/saveCompany",
        data: JSON.stringify(groupcompany),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
 
                console.log("Hello world! ajax");
             //   $("#companydd tr").remove();
                var $tr = $('<tr>');
                 $.each(data, function(i, item) {
                       
                         $tr.append(
                            $('<td>').text(item)
                        ); //.appendTo('#records_table');
                       
                    });
                 $('#companydd').append();
                 
            $("#nextBtn").prop("disabled", false);
 
        },
        error: function (e) {
 
            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            $('#companydd').html(json);
 
            console.log("ERROR : ", e);
            $("#nextBtn").prop("disabled", false);
 
        }
   
});
    
}// ajax call ends



