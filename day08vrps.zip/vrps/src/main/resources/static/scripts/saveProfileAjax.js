$(document).ready(function(){
	
	$("nextBtn").click(function(){
		if()
	});
	
	
	
	
	
	
});